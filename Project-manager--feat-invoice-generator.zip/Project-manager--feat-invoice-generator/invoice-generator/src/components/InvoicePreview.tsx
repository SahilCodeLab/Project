import * as React from "react"
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
  TableFooter,
} from "@/components/ui/table"

interface Item {
  description: string
  quantity: number
  rate: number
}

interface InvoicePreviewProps {
  companyName: string
  companyAddress: string
  companyLogo: string
  clientName: string
  clientAddress: string
  invoiceNumber: string
  issueDate: string
  dueDate: string
  items: Item[]
  tax: number
}

export const InvoicePreview = React.forwardRef<HTMLDivElement, InvoicePreviewProps>(
  ({
    companyName,
    companyAddress,
    companyLogo,
    clientName,
    clientAddress,
    invoiceNumber,
    issueDate,
    dueDate,
    items,
    tax,
  }, ref) => {
    const calculateSubtotal = () => {
      return items.reduce((total, item) => total + item.quantity * item.rate, 0)
    }

    const calculateTotal = () => {
      const subtotal = calculateSubtotal()
      const taxAmount = subtotal * (tax / 100)
      return subtotal + taxAmount
    }

    const subtotal = calculateSubtotal()
    const taxAmount = subtotal * (tax / 100)
    const total = calculateTotal()

    return (
      <div ref={ref} className="border rounded-lg p-8">
        <div className="flex justify-between mb-8">
          <div className="flex items-center">
            {companyLogo && <img src={companyLogo} alt="Company Logo" className="h-16 w-16 mr-4" />}
            <div>
              <h2 className="text-2xl font-bold">{companyName}</h2>
              <p>{companyAddress}</p>
            </div>
          </div>
          <div className="text-right">
            <h1 className="text-4xl font-bold">INVOICE</h1>
            <p>#{invoiceNumber}</p>
          </div>
        </div>
        <div className="flex justify-between mb-8">
          <div>
            <h3 className="font-bold">Bill To:</h3>
            <p>{clientName}</p>
            <p>{clientAddress}</p>
          </div>
          <div className="text-right">
            <p>
              <strong>Date of Issue:</strong> {issueDate}
            </p>
            <p>
              <strong>Due Date:</strong> {dueDate}
            </p>
          </div>
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Description</TableHead>
              <TableHead className="w-[100px]">Quantity</TableHead>
              <TableHead className="w-[100px]">Rate</TableHead>
              <TableHead className="w-[100px] text-right">Total</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.map((item, index) => (
              <TableRow key={index}>
                <TableCell>{item.description}</TableCell>
                <TableCell>{item.quantity}</TableCell>
                <TableCell>${item.rate.toFixed(2)}</TableCell>
                <TableCell className="text-right">
                  ${(item.quantity * item.rate).toFixed(2)}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
          <TableFooter>
            <TableRow>
              <TableCell colSpan={3} className="text-right">Subtotal</TableCell>
              <TableCell className="text-right">${subtotal.toFixed(2)}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell colSpan={3} className="text-right">Tax ({tax}%)</TableCell>
              <TableCell className="text-right">${taxAmount.toFixed(2)}</TableCell>
            </TableRow>
            <TableRow>
              <TableCell colSpan={3} className="text-right font-bold">Total</TableCell>
              <TableCell className="text-right font-bold">${total.toFixed(2)}</TableCell>
            </TableRow>
          </TableFooter>
        </Table>
      </div>
    )
  }
)
