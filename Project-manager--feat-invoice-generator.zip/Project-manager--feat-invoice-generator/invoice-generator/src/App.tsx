import { useState, useRef } from "react"
import { useReactToPrint } from "react-to-print"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
  TableFooter,
} from "@/components/ui/table"
import { InvoicePreview } from "@/components/InvoicePreview"
import { Trash2 } from "lucide-react"

interface Item {
  description: string
  quantity: number
  rate: number
}

function App() {
  const [companyName, setCompanyName] = useState("Your Company")
  const [companyAddress, setCompanyAddress] = useState("123 Main St")
  const [companyLogo, setCompanyLogo] = useState("")
  const [clientName, setClientName] = useState("Client Co.")
  const [clientAddress, setClientAddress] = useState("456 Client Ave")
  const [invoiceNumber, setInvoiceNumber] = useState("INV-001")
  const [issueDate, setIssueDate] = useState(new Date().toISOString().split('T')[0])
  const [dueDate, setDueDate] = useState(new Date().toISOString().split('T')[0])
  const [tax, setTax] = useState(0)
  const [items, setItems] = useState<Item[]>([
    { description: "Web Design", quantity: 1, rate: 5000 },
    { description: "SEO", quantity: 1, rate: 2000 },
  ])

  const invoicePreviewRef = useRef<HTMLDivElement>(null)

  const handlePrint = useReactToPrint({
    content: () => invoicePreviewRef.current,
  })

  const handleAddItem = () => {
    setItems([...items, { description: "", quantity: 1, rate: 0 }])
  }

  const handleRemoveItem = (index: number) => {
    const newItems = [...items]
    newItems.splice(index, 1)
    setItems(newItems)
  }

  const handleItemChange = (index: number, field: keyof Item, value: any) => {
    const newItems = [...items]
    newItems[index][field] = value
    setItems(newItems)
  }

  const calculateSubtotal = () => {
    return items.reduce((total, item) => total + item.quantity * item.rate, 0)
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-4">Invoice Generator</h1>
      <div className="grid grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl font-bold mb-4">Invoice Details</h2>
          <div className="grid gap-4">
            <div>
              <h3 className="text-lg font-medium mb-2">Your Company</h3>
              <div className="grid gap-2">
                <Label htmlFor="company-name">Company Name</Label>
                <Input
                  id="company-name"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  placeholder="Your Company"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="company-address">Address</Label>
                <Input
                  id="company-address"
                  value={companyAddress}
                  onChange={(e) => setCompanyAddress(e.target.value)}
                  placeholder="123 Main St"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="company-logo">Logo URL</Label>
                <Input
                  id="company-logo"
                  value={companyLogo}
                  onChange={(e) => setCompanyLogo(e.target.value)}
                  placeholder="https://your-logo.com/logo.png"
                />
              </div>
            </div>
            <div>
              <h3 className="text-lg font-medium mb-2">Client</h3>
              <div className="grid gap-2">
                <Label htmlFor="client-name">Client Name</Label>
                <Input
                  id="client-name"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="Client Co."
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="client-address">Address</Label>
                <Input
                  id="client-address"
                  value={clientAddress}
                  onChange={(e) => setClientAddress(e.target.value)}
                  placeholder="456 Client Ave"
                />
              </div>
            </div>
            <div>
              <h3 className="text-lg font-medium mb-2">Invoice</h3>
              <div className="grid grid-cols-3 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="invoice-number">Invoice Number</Label>
                  <Input
                    id="invoice-number"
                    value={invoiceNumber}
                    onChange={(e) => setInvoiceNumber(e.target.value)}
                    placeholder="INV-001"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="issue-date">Date of Issue</Label>
                  <Input
                    id="issue-date"
                    type="date"
                    value={issueDate}
                    onChange={(e) => setIssueDate(e.target.value)}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="due-date">Due Date</Label>
                  <Input
                    id="due-date"
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                  />
                </div>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-medium mb-2">Items</h3>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Description</TableHead>
                    <TableHead className="w-[100px]">Quantity</TableHead>
                    <TableHead className="w-[100px]">Rate</TableHead>
                    <TableHead className="w-[100px] text-right">Total</TableHead>
                    <TableHead className="w-[50px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {items.map((item, index) => (
                    <TableRow key={index}>
                      <TableCell>
                        <Input
                          value={item.description}
                          onChange={(e) =>
                            handleItemChange(index, "description", e.target.value)
                          }
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={item.quantity}
                          onChange={(e) =>
                            handleItemChange(index, "quantity", +e.target.value)
                          }
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={item.rate}
                          onChange={(e) =>
                            handleItemChange(index, "rate", +e.target.value)
                          }
                        />
                      </TableCell>
                      <TableCell className="text-right">
                        ${(item.quantity * item.rate).toFixed(2)}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleRemoveItem(index)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <Button onClick={handleAddItem} variant="outline" className="mt-2">
                Add Item
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                    <Label htmlFor="tax">Tax (%)</Label>
                    <Input
                        id="tax"
                        type="number"
                        value={tax}
                        onChange={(e) => setTax(+e.target.value)}
                    />
                </div>
            </div>
          </div>
        </div>
        <div>
          <h2 className="text-2xl font-bold mb-4">Preview</h2>
          <InvoicePreview
            ref={invoicePreviewRef}
            companyName={companyName}
            companyAddress={companyAddress}
            companyLogo={companyLogo}
            clientName={clientName}
            clientAddress={clientAddress}
            invoiceNumber={invoiceNumber}
            issueDate={issueDate}
            dueDate={dueDate}
            items={items}
            tax={tax}
          />
        </div>
      </div>
      <div className="mt-8 flex justify-end">
        <Button onClick={handlePrint}>Download PDF</Button>
      </div>
    </div>
  )
}

export default App
